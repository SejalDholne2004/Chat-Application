SQL Storage Adapter
===================

.. autoclass:: chatterbot.storage.SQLStorageAdapter
   :members:
