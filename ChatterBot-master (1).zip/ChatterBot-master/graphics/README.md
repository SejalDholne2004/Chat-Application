# ChatterBot Graphics

Concept art and imagery for ChatterBot was designed by [Griffin Cox](https://github.com/griffincx).

Files using a `.xcf` format can be viewed and edited using [GIMP](https://www.gimp.org/).
